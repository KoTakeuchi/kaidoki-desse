# main/constants.py
SORT_OPTIONS = [
    ("new", "新しい順"),
    ("old", "古い順"),
    ("cheap", "安い順"),
    ("expensive", "高い順"),
]
