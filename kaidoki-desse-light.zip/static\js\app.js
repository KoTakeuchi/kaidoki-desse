// 将来のグラフ描画やトグル用
console.log("Kaidoki-Desse UI loaded");
